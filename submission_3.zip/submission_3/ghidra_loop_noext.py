import os
import subprocess

# Path to your Ghidra installation
ghidra_path = r"C:\Users\someDude\Desktop\ghidra_11.2_PUBLIC_20240926\ghidra_11.2_PUBLIC"  # Update with your Ghidra path
ghidra_headless_path = os.path.join(ghidra_path, "support", "analyzeHeadless.bat")

# Project directory (where Ghidra stores project data) - can be temporary
project_dir = r"C:\Users\someDude\Downloads\new_analysis"

# Directory containing the malware samples (we edited the input directory for each apt folder)
malware_folder = r"C:\Users\someDude\Downloads\Group 8 samples\Executables_main\fin8_executables"

# Directory to save the extracted .opcode files
output_folder = r"C:\Users\someDude\Downloads\Opcodes"

# Path to the Ghidra extraction script in the Scripts directory
script_name = "ExtractOpCodes.py"  # Name of the script saved in Ghidra’s Scripts directory

# Ensure output directory exists
os.makedirs(output_folder, exist_ok=True)

# Loop through each file in the malware folder
for filename in os.listdir(malware_folder):
    file_path = os.path.join(malware_folder, filename)
    
    # Check if it's a file (and not a directory)
    if os.path.isfile(file_path):
        # Define the output file name based on the malware file
        output_file = os.path.join(output_folder, filename + ".opcode")
        
        # Command to run Ghidra headlessly with the extraction script
        command = [
            ghidra_headless_path,
            project_dir,
            "TempProject",
            "-import", file_path,
            "-postScript", script_name,
            output_file  # Pass the output file to the script if it accepts an output argument
        ]
        
        print(f"Running Ghidra on {filename}...")
        # Run the command
        subprocess.run(command, check=True)
        print(f"Output saved to {output_file}")

print("All files processed.")
